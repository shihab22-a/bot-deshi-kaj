# দেশি কাজ (Deshi Kaj) - One Tap Income Telegram Bot 🇧🇩

একটি সম্পূর্ণ প্রোডাকশন-রেডি টেলিগ্রাম ওয়ান ট্যাপ ইনকাম বট। আপনার দেওয়া BotFather টোকেন ইতিমধ্যে কনফিগার করা আছে।

## 🔑 কনফিগার করা তথ্যসমূহ:
- **Bot Token**: `8627561431:AAGcwGhez41EhqIGbLQh-GU8Q5WjGnnIEJ0`
- **Admin ID**: `6953485936`
- **Smart Link (Zone)**: `31402897` (`https://profitablegatecpm.com/31402897`)
- **Bot ID**: `8627561431`

## 🚀 ফাইল পরিচিতি:
- `bot.py` : aiogram 3.x মেইন হ্যান্ডলার (কাজের স্থান, টাইমার, ব্যালেন্স, উইথড্র, রেফারেল)
- `database.py` : aiosqlite ডাটাবেস হ্যান্ডলার
- `config.py` : টোকেন, রিওয়ার্ড ও কুলডাউন কনফিগারেশন (সক্রিয় টোকেন সহ)
- `requirements.txt` : ডিপেনডেন্সি তালিকা
- `.env.example` : এনভায়রনমেন্ট কনফিগারেশন
- `render.yaml` : Render.com এর জন্য ১-ক্লিক ব্লুপ্রিন্ট
- `Procfile` : Heroku / Render / Railway প্রসেস ফাইল
- `Dockerfile` : ক্লাউড কন্টেইনার ফাইল
- `deshikaj.service` : উবুন্টু VPS অটো-রিস্টার্ট Systemd সার্ভিস
- `schema.sql` : ডাটাবেস টেবিল স্কিমা

## ☁️ Render.com এ ১-ক্লিকে ২৪/৭ হোস্ট করার নিয়ম:
1. এই ফাইলের সব কোড আপনার একটি নতুন GitHub Repository তে আপলোড (Push) করুন।
2. https://render.com এ লগইন করে **New +** -> **Blueprint** অথবা **Background Worker** সিলেক্ট করুন।
3. আপনার গিটহাব সিলেক্ট করলে `render.yaml` নিজে থেকেই সব সেটআপ করে ২৪/৭ চালু রাখবে।

## 💻 লোকাল কম্পিউটারে রান করার নিয়ম:
1. ভার্চুয়াল এনভায়রনমেন্ট তৈরি করুন:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   venv\Scripts\activate     # Windows
   ```

2. প্রয়োজনীয় লাইব্রেরি ইনস্টল করুন:
   ```bash
   pip install -r requirements.txt
   ```

3. বট রান করুন:
   ```bash
   python bot.py
   ```
