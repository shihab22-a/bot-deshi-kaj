"""
দেশি কাজ - ডাটাবেস হ্যান্ডলার (aiosqlite)
ইউজার ডাটা, ৫ মিনিটের কুলডাউন ট্র্যাকিং ও উইথড্রাল স্টোরেজ
"""

import aiosqlite
import config

DB_FILE = config.DATABASE_PATH


async def init_db():
    async with aiosqlite.connect(DB_FILE) as db:
        # ইউজার টেবিল
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                first_name TEXT,
                username TEXT,
                balance REAL DEFAULT 0.0,
                total_tasks INTEGER DEFAULT 0,
                last_task_time INTEGER DEFAULT 0,
                referred_by INTEGER,
                total_refers INTEGER DEFAULT 0,
                referral_earnings REAL DEFAULT 0.0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # উইথড্রাল রিকোয়েস্ট টেবিল
        await db.execute("""
            CREATE TABLE IF NOT EXISTS withdrawals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                method TEXT,
                account_number TEXT,
                amount REAL,
                status TEXT DEFAULT 'pending',
                trx_id TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()


async def add_or_get_user(user_id: int, first_name: str, username: str, referrer_id: int = None) -> bool:
    """নতুন ইউজার যুক্ত করে, নতুন হলে True রিটার্ন করে"""
    async with aiosqlite.connect(DB_FILE) as db:
        cursor = await db.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        if row:
            return False

        await db.execute(
            """INSERT INTO users (user_id, first_name, username, referred_by)
               VALUES (?, ?, ?, ?)""",
            (user_id, first_name, username, referrer_id)
        )
        await db.commit()
        return True


async def get_user(user_id: int) -> dict | None:
    async with aiosqlite.connect(DB_FILE) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return dict(row) if row else None


async def credit_task_reward(user_id: int, reward: float, current_time: int) -> float:
    """টাস্ক সম্পন্ন হলে ব্যালেন্স ও শেষ কাজের সময় আপডেট করে"""
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            """UPDATE users 
               SET balance = balance + ?, 
                   total_tasks = total_tasks + 1, 
                   last_task_time = ? 
               WHERE user_id = ?""",
            (reward, current_time, user_id)
        )
        await db.commit()
        cursor = await db.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = await cursor.fetchone()
        return row[0] if row else 0.0


async def add_referral_bonus(referrer_id: int, bonus: float):
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute(
            """UPDATE users 
               SET balance = balance + ?, 
                   total_refers = total_refers + 1,
                   referral_earnings = referral_earnings + ?
               WHERE user_id = ?""",
            (bonus, bonus, referrer_id)
        )
        await db.commit()


async def create_withdrawal(user_id: int, method: str, account_number: str, amount: float) -> int:
    """ব্যালেন্স কেটে উইথড্রাল রিকোয়েস্ট তৈরি করে"""
    async with aiosqlite.connect(DB_FILE) as db:
        await db.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?", (amount, user_id))
        cursor = await db.execute(
            """INSERT INTO withdrawals (user_id, method, account_number, amount, status)
               VALUES (?, ?, ?, ?, 'pending')""",
            (user_id, method, account_number, amount)
        )
        req_id = cursor.lastrowid
        await db.commit()
        return req_id


async def get_system_stats() -> dict:
    async with aiosqlite.connect(DB_FILE) as db:
        u_cursor = await db.execute("SELECT COUNT(*), SUM(total_tasks) FROM users")
        u_row = await u_cursor.fetchone()
        total_users = u_row[0] or 0
        total_tasks = u_row[1] or 0

        p_cursor = await db.execute("SELECT COUNT(*) FROM withdrawals WHERE status = 'pending'")
        p_row = await p_cursor.fetchone()
        pending_withdrawals = p_row[0] or 0

        paid_cursor = await db.execute("SELECT SUM(amount) FROM withdrawals WHERE status = 'approved'")
        paid_row = await paid_cursor.fetchone()
        total_paid = paid_row[0] or 0.0

        return {
            "total_users": total_users,
            "total_tasks": total_tasks,
            "pending_withdrawals": pending_withdrawals,
            "total_paid": round(total_paid, 2)
        }


async def get_all_user_ids() -> list[int]:
    async with aiosqlite.connect(DB_FILE) as db:
        cursor = await db.execute("SELECT user_id FROM users")
        rows = await cursor.fetchall()
        return [r[0] for r in rows]
