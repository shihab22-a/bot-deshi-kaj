"""
দেশি কাজ - কনফিগারেশন ফাইল
টেলিগ্রাম বটের সমস্ত সেটিংস এখানে রাখা হয়েছে
"""

import os
from dotenv import load_dotenv

load_dotenv()

# টেলিগ্রাম বট টোকেন (আপনার BotFather টোকেন কনফিগার করা হয়েছে)
BOT_TOKEN = os.getenv("BOT_TOKEN", "8627561431:AAGcwGhez41EhqIGbLQh-GU8Q5WjGnnIEJ0")

# অ্যাডমিন আইডি (আপনার ব্যক্তিগত আইডি সেট করা হয়েছে)
ADMIN_ID = int(os.getenv("ADMIN_ID", "6953485936"))
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "DeshiAdmin")

# ডাটাবেস লোকেশন
DATABASE_PATH = os.getenv("DATABASE_PATH", "deshikaj.db")

# আয় ও কুলডাউন সেটিংস
COOLDOWN_SECONDS = 300  # ৩০০ সেকেন্ড = ৫ মিনিট
TASK_REWARD = 2.50       # প্রতি ক্লিকে ৳২.৫০
REFERRAL_BONUS = 5.00    # প্রতি রেফারে ৳৫.০০
MIN_WITHDRAWAL = 50.00   # নূন্যতম উইথড্র ৳৫০.০০

# স্পনসর স্মার্টলিংক সেটিংস (আপনার Smartlink 31402897 যুক্ত)
AD_TITLE = "🔥 বিশেষ অফার: গেম খেলুন ও ইনকাম করুন!"
AD_DESCRIPTION = "আমাদের স্পনসর প্ল্যাটফর্মে এখনই সাইন আপ করুন এবং ফ্রিতে প্রথম ক্যাশব্যাক গ্রহণ করুন।"
AD_REDIRECT_URL = os.getenv("AD_REDIRECT_URL", "https://profitablegatecpm.com/31402897")
AD_IMAGE_URL = os.getenv("AD_IMAGE_URL", "https://i.ibb.co/example-ad-banner.jpg")
