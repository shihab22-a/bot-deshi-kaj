"""
দেশি কাজ (Deshi Kaj) - One Tap Income Telegram Bot
লাইব্রেরি: aiogram 3.x (Async & Production-Ready)
ডাটাবেস: SQLite (aiosqlite) / PostgreSQL
"""

import asyncio
import logging
import time
from datetime import datetime
from aiogram import Bot, Dispatcher, F, types
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)

import config
import database as db

# লগিং কনফিগারেশন
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


# উইথড্র প্রসেসের জন্য FSM স্টেট
class WithdrawState(StatesGroup):
    choosing_method = State()
    entering_account = State()
    entering_amount = State()


# ব্রডকাস্টের জন্য FSM স্টেট
class BroadcastState(StatesGroup):
    entering_message = State()


# বাংলা সংখ্যা কনভার্টার হেল্পার
def to_bangla_digits(number: int | float | str) -> str:
    bangla_digits = {"0": "০", "1": "১", "2": "২", "3": "৩", "4": "৪",
                     "5": "৫", "6": "৬", "7": "৭", "8": "৮", "9": "৯", ".": "."}
    return "".join(bangla_digits.get(ch, ch) for ch in str(number))


# মেইন মেনু কী-বোর্ড (বাংলা)
def get_main_keyboard():
    keyboard = [
        [KeyboardButton(text="🚀 কাজের স্থান (Tap to Earn)")],
        [KeyboardButton(text="💰 আমার ব্যালেন্স"), KeyboardButton(text="👥 রেফার এবং আয়")],
        [KeyboardButton(text="💳 উইথড্র (পেমেন্ট)"), KeyboardButton(text="ℹ️ সাহায্য ও নিয়মাবলী")]
    ]
    return ReplyKeyboardMarkup(keyboard=keyboard, resize_keyboard=True)


# ==========================================
# /start কমান্ড হ্যান্ডলার (রেফারেল সহ)
# ==========================================
@dp.message(CommandStart())
async def cmd_start(message: types.Message):
    user_id = message.from_user.id
    first_name = message.from_user.first_name or "ইউজার"
    username = message.from_user.username or ""

    # রেফারেল কোড চেক
    args = message.text.split()[1:]
    referrer_id = None
    if args and args[0].startswith("ref_"):
        try:
            ref_candidate = int(args[0].replace("ref_", ""))
            if ref_candidate != user_id:
                referrer_id = ref_candidate
        except ValueError:
            referrer_id = None

    is_new = await db.add_or_get_user(user_id, first_name, username, referrer_id)

    # নতুন ইউজার হলে এবং ভ্যালিড রেফারার থাকলে বোনাস দিন
    if is_new and referrer_id:
        await db.add_referral_bonus(referrer_id, config.REFERRAL_BONUS)
        try:
            await bot.send_message(
                referrer_id,
                f"🎉 সুখবর! আপনার রেফারেল লিংক ব্যবহার করে **{first_name}** জয়েন করেছেন!\n"
                f"🎁 আপনি পেয়েছেন: **৳{to_bangla_digits(config.REFERRAL_BONUS)}** বোনাস।"
            )
        except Exception as e:
            logger.warning(f"Could not notify referrer {referrer_id}: {e}")

    welcome_text = (
        f"স্বাগতম **{first_name}**, 'দেশি কাজ' বোটে! 🇧🇩\n\n"
        f"এখানে আপনি প্রতি ৫ মিনিট পর পর বিজ্ঞাপন দেখে সহজে টাকা আয় করতে পারবেন।\n\n"
        f"📌 **কীভাবে কাজ করবেন?**\n"
        f"১. নিচে '🚀 কাজের স্থান' বাটনে চাপ দিন।\n"
        f"২. স্পনসর করা বিজ্ঞাপনটি দেখুন।\n"
        f"৩. ব্যালেন্সে সাথে সাথে টাকা যোগ হবে।\n"
        f"৪. বিকাশ, নগদ বা রকেটে টাকা তুলে নিন!\n\n"
        f"শুরু করতে নিচের যেকোনো বাটন ব্যবহার করুন 👇"
    )
    await message.answer(welcome_text, reply_markup=get_main_keyboard(), parse_mode="Markdown")


# ==========================================
# 🚀 কাজের স্থান (One Tap Task with 5-Min Cooldown)
# ==========================================
@dp.message(F.text == "🚀 কাজের স্থান (Tap to Earn)")
async def task_handler(message: types.Message):
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    if not user:
        await message.answer("অনুগ্রহ করে প্রথমে /start কমান্ড দিন।")
        return

    last_task_time = user.get("last_task_time") or 0
    current_time = int(time.time())
    cooldown = config.COOLDOWN_SECONDS  # ৩০০ সেকেন্ড = ৫ মিনিট
    time_passed = current_time - last_task_time

    # ৫ মিনিট কুলডাউন চেক
    if time_passed < cooldown:
        remaining = cooldown - time_passed
        mins = remaining // 60
        secs = remaining % 60
        mins_bn = to_bangla_digits(mins)
        secs_bn = to_bangla_digits(secs)

        wait_msg = (
            f"⏳ **দয়া করে অপেক্ষা করুন!**\n\n"
            f"আপনি মাত্র কাজ সম্পন্ন করেছেন।\n"
            f"আরো **{mins_bn} মিনিট {secs_bn} সেকেন্ড** পর আবার কাজ করতে পারবেন।\n\n"
            f"💡 *টিপস: বেশি আয় করতে আপনার বন্ধুদের রেফার করুন!*"
        )
        await message.answer(wait_msg, parse_mode="Markdown")
        return

    # কুলডাউন পার হলে বিজ্ঞাপন দেখান (Adsterra / Monetag / Sponsor)
    ad_caption = (
        f"🎯 **আজকের স্পনসরড কাজ**\n\n"
        f"📢 **{config.AD_TITLE}**\n"
        f"{config.AD_DESCRIPTION}\n\n"
        f"💰 **রিওয়ার্ড:** ৳{to_bangla_digits(config.TASK_REWARD)}\n\n"
        f"👉 নিচের '🌐 অ্যাড ভিজিট করুন' বাটনে ক্লিক করে বিজ্ঞাপনটি দেখুন এবং '✅ রিওয়ার্ড ক্লেইম করুন' চাপুন।"
    )

    # ইনলাইন অ্যাড বাটন
    inline_kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🌐 অ্যাড ভিজিট করুন (স্পনসর লিংক)", url=config.AD_REDIRECT_URL)],
        [InlineKeyboardButton(text="✅ রিওয়ার্ড ক্লেইম করুন", callback_data=f"claim_reward_{current_time}")]
    ])

    if config.AD_IMAGE_URL:
        try:
            await message.answer_photo(
                photo=config.AD_IMAGE_URL,
                caption=ad_caption,
                reply_markup=inline_kb,
                parse_mode="Markdown"
            )
            return
        except Exception:
            pass

    await message.answer(ad_caption, reply_markup=inline_kb, parse_mode="Markdown")


# ==========================================
# রিওয়ার্ড ক্লেইম কলব্যাক হ্যান্ডলার
# ==========================================
@dp.callback_query(F.data.startswith("claim_reward_"))
async def callback_claim_reward(callback: types.CallbackQuery):
    user_id = callback.from_user.id
    user = await db.get_user(user_id)
    if not user:
        await callback.answer("ডাটা পাওয়া যায়নি। /start চাপুন।", show_alert=True)
        return

    last_task_time = user.get("last_task_time") or 0
    current_time = int(time.time())

    # ডাবল ক্লিক বা রি-ক্লিক রোধ
    if current_time - last_task_time < config.COOLDOWN_SECONDS:
        await callback.answer("⚠️ আপনি ইতিমধ্যে এই কাজটি করেছেন বা টাইমার চলমান!", show_alert=True)
        return

    # রিওয়ার্ড যোগ এবং কুলডাউন আপডেট
    new_balance = await db.credit_task_reward(user_id, config.TASK_REWARD, current_time)

    await callback.message.edit_reply_markup(reply_markup=None)
    success_text = (
        f"🎉 **অভিনন্দন!**\n\n"
        f"আপনি সফলভাবে বিজ্ঞাপন দেখেছেন এবং **৳{to_bangla_digits(config.TASK_REWARD)}** আপনার একাউন্টে যোগ হয়েছে!\n"
        f"💵 বর্তমান ব্যালেন্স: **৳{to_bangla_digits(round(new_balance, 2))}**\n\n"
        f"🕒 পরবর্তী কাজ করতে পারবেন ঠিক **৫ মিনিট** পর।"
    )
    await callback.message.answer(success_text, parse_mode="Markdown")
    await callback.answer("রিওয়ার্ড সফলভাবে জমা হয়েছে! 💰")


# ==========================================
# 💰 আমার ব্যালেন্স হ্যান্ডলার
# ==========================================
@dp.message(F.text == "💰 আমার ব্যালেন্স")
async def balance_handler(message: types.Message):
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    if not user:
        await message.answer("দয়া করে /start দিন।")
        return

    balance_bn = to_bangla_digits(round(user.get("balance", 0.0), 2))
    tasks_bn = to_bangla_digits(user.get("total_tasks", 0))
    refers_bn = to_bangla_digits(user.get("total_refers", 0))
    ref_earnings_bn = to_bangla_digits(round(user.get("referral_earnings", 0.0), 2))

    balance_text = (
        f"📊 **আপনার ড্যাশবোর্ড ও ব্যালেন্স**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👤 ইউজার নাম: {message.from_user.first_name}\n"
        f"🆔 ইউজার আইডি: `{user_id}`\n"
        f"💵 বর্তমান ব্যালেন্স: **৳{balance_bn}**\n"
        f"🎯 সম্পন্ন কাজ: **{tasks_bn} টি**\n"
        f"👥 মোট রেফারেল: **{refers_bn} জন**\n"
        f"🎁 রেফার আয়: **৳{ref_earnings_bn}**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"💡 উইথড্র করতে নিচে '💳 উইথড্র' বাটনে চাপ দিন (নূন্যতম ৳{to_bangla_digits(config.MIN_WITHDRAWAL)})।"
    )
    await message.answer(balance_text, parse_mode="Markdown")


# ==========================================
# 👥 রেফার এবং আয় হ্যান্ডলার
# ==========================================
@dp.message(F.text == "👥 রেফার এবং আয়")
async def referral_handler(message: types.Message):
    user_id = message.from_user.id
    bot_info = await bot.get_me()
    ref_link = f"https://t.me/{bot_info.username}?start=ref_{user_id}"

    user = await db.get_user(user_id)
    refers_bn = to_bangla_digits(user.get("total_refers", 0) if user else 0)
    bonus_bn = to_bangla_digits(config.REFERRAL_BONUS)

    ref_text = (
        f"👥 **রেফারেল প্রোগ্রাম - দেশি কাজ**\n\n"
        f"আপনার বন্ধুদের আমন্ত্রণ জানান এবং আনলিমিটেড আয় করুন!\n\n"
        f"🎁 **রেফারেল বোনাস:** প্রতি সফল জয়ে **৳{bonus_bn}**\n"
        f"📊 আপনার বর্তমান রেফারেল: **{refers_bn} জন**\n\n"
        f"🔗 **আপনার ইউনিক রেফারেল লিংক:**\n"
        f"`{ref_link}`\n\n"
        f"*(লিংকটি কপি করে ফেসবুক, টেলিগ্রাম ও হোয়াটসঅ্যাপে শেয়ার করুন)*"
    )
    inline_share = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📤 বন্ধুদের সাথে শেয়ার করুন",
            url=f"https://t.me/share/url?url={ref_link}&text=টেলিগ্রামে%20বিজ্ঞাপন%20দেখে%20টাকা%20আয়%20করুন%20প্রতিদিন!"
        )]
    ])
    await message.answer(ref_text, reply_markup=inline_share, parse_mode="Markdown")


# ==========================================
# 💳 উইথড্র সিস্টেম (FSM সহ বিকাশ/নগদ/রকেট)
# ==========================================
@dp.message(F.text == "💳 উইথড্র (পেমেন্ট)")
async def withdraw_start(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    user = await db.get_user(user_id)
    balance = user.get("balance", 0.0) if user else 0.0

    if balance < config.MIN_WITHDRAWAL:
        await message.answer(
            f"⚠️ **পর্যাপ্ত ব্যালেন্স নেই!**\n\n"
            f"💵 আপনার ব্যালেন্স: ৳{to_bangla_digits(round(balance, 2))}\n"
            f"📌 নূন্যতম উইথড্র: ৳{to_bangla_digits(config.MIN_WITHDRAWAL)}\n\n"
            f"আরো কিছু কাজ করে টাকা তুলে নিন!",
            parse_mode="Markdown"
        )
        return

    method_keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="বিকাশ (bKash)"), KeyboardButton(text="নগদ (Nagad)")],
            [KeyboardButton(text="রকেট (Rocket)"), KeyboardButton(text="❌ বাতিল করুন")]
        ],
        resize_keyboard=True
    )
    await message.answer(
        "💳 **পেমেন্ট মেথড নির্বাচন করুন:**\n\nটাকা গ্রহণ করতে আপনি কোন মাধ্যমে নিতে চান?",
        reply_markup=method_keyboard,
        parse_mode="Markdown"
    )
    await state.set_state(WithdrawState.choosing_method)


@dp.message(WithdrawState.choosing_method)
async def withdraw_method_chosen(message: types.Message, state: FSMContext):
    text = message.text
    if text == "❌ বাতিল করুন":
        await state.clear()
        await message.answer("উইথড্র বাতিল করা হয়েছে।", reply_markup=get_main_keyboard())
        return

    valid_methods = ["বিকাশ (bKash)", "নগদ (Nagad)", "রকেট (Rocket)"]
    if text not in valid_methods:
        await message.answer("দয়া করে নিচের বাটন থেকে সঠিক মেথড বাছুন।")
        return

    method_clean = "bKash" if "bKash" in text else "Nagad" if "Nagad" in text else "Rocket"
    await state.update_data(payment_method=method_clean)

    cancel_kb = ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ বাতিল করুন")]], resize_keyboard=True)
    await message.answer(
        f"📱 **আপনার {method_clean} একাউন্ট নাম্বারটি লিখুন:**\n(উদাহরণ: 01712345678)",
        reply_markup=cancel_kb,
        parse_mode="Markdown"
    )
    await state.set_state(WithdrawState.entering_account)


@dp.message(WithdrawState.entering_account)
async def withdraw_account_entered(message: types.Message, state: FSMContext):
    if message.text == "❌ বাতিল করুন":
        await state.clear()
        await message.answer("উইথড্র বাতিল করা হয়েছে।", reply_markup=get_main_keyboard())
        return

    account_no = message.text.strip()
    if not (account_no.isdigit() and len(account_no) in [11, 12]):
        await message.answer("⚠️ ভুল মোবাইল নাম্বার! অনুগ্রহ করে ১১ ডিজিটের সঠিক নাম্বার লিখুন।")
        return

    await state.update_data(account_number=account_no)
    await message.answer(
        f"💵 **আপনি কত টাকা উইথড্র করতে চান লিখুন:**\n(নূন্যতম ৳{to_bangla_digits(config.MIN_WITHDRAWAL)})"
    )
    await state.set_state(WithdrawState.entering_amount)


@dp.message(WithdrawState.entering_amount)
async def withdraw_amount_entered(message: types.Message, state: FSMContext):
    if message.text == "❌ বাতিল করুন":
        await state.clear()
        await message.answer("উইথড্র বাতিল করা হয়েছে।", reply_markup=get_main_keyboard())
        return

    try:
        amount = float(message.text.strip())
    except ValueError:
        await message.answer("⚠️ অনুগ্রহ করে সঠিক অংকের সংখ্যা লিখুন (যেমন: 50)।")
        return

    user_id = message.from_user.id
    user = await db.get_user(user_id)
    balance = user.get("balance", 0.0) if user else 0.0

    if amount < config.MIN_WITHDRAWAL:
        await message.answer(f"⚠️ নূন্যতম উইথড্র ৳{to_bangla_digits(config.MIN_WITHDRAWAL)}।")
        return

    if amount > balance:
        await message.answer(f"⚠️ আপনার একাউন্টে পর্যাপ্ত টাকা নেই! বর্তমান ব্যালেন্স: ৳{to_bangla_digits(balance)}")
        return

    data = await state.get_data()
    method = data["payment_method"]
    account_no = data["account_number"]

    # ডাটাবেসে উইথড্রাল রিকোয়েস্ট তৈরি ও ব্যালেন্স মাইনাস
    req_id = await db.create_withdrawal(user_id, method, account_no, amount)
    await state.clear()

    confirm_msg = (
        f"✅ **আপনার উইথড্র রিকোয়েস্ট জমা হয়েছে!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🆔 রিকোয়েস্ট নং: #{req_id}\n"
        f"💳 মাধ্যম: **{method}**\n"
        f"📱 নাম্বার: `{account_no}`\n"
        f"💰 অংক: **৳{to_bangla_digits(amount)}**\n"
        f"⏳ স্ট্যাটাস: **অপেক্ষারত (Pending)**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"অ্যাডমিন ম্যানুয়ালি চেক করে ২৪ ঘণ্টার মধ্যে পেমেন্ট পাঠিয়ে দেবে।"
    )
    await message.answer(confirm_msg, reply_markup=get_main_keyboard(), parse_mode="Markdown")

    # অ্যাডমিনকে নোটিফিকেশন পাঠানো
    admin_alert = (
        f"🚨 **নতুন উইথড্রাল রিকোয়েস্ট!**\n\n"
        f"রিকোয়েস্ট নং: #{req_id}\n"
        f"ইউজার আইডি: `{user_id}`\n"
        f"মেথড: {method}\n"
        f"নাম্বার: `{account_no}`\n"
        f"টাকা: ৳{amount}\n\n"
        f"অনুমোদন দিতে লিখুন: `/approve {req_id} <TrxID>`"
    )
    try:
        await bot.send_message(config.ADMIN_ID, admin_alert, parse_mode="Markdown")
    except Exception as e:
        logger.warning(f"Admin alert failed: {e}")


# ==========================================
# ℹ️ সাহায্য ও নিয়মাবলী
# ==========================================
@dp.message(F.text == "ℹ️ সাহায্য ও নিয়মাবলী")
async def help_handler(message: types.Message):
    help_text = (
        f"ℹ️ **দেশি কাজ - সাধারণ নিয়মাবলী ও FAQ**\n\n"
        f"১. প্রতি ৫ মিনিটে একবার 'কাজের স্থান'-এ ক্লিক করে বিজ্ঞাপন দেখে আয় করতে পারবেন।\n"
        f"২. বিজ্ঞাপনে ক্লিক করে ৫ সেকেন্ড অবস্থান করতে হবে।\n"
        f"৩. নূন্যতম ৳{to_bangla_digits(config.MIN_WITHDRAWAL)} হলেই বিকাশ/নগদ/রকেটে পেমেন্ট রিকোয়েস্ট করা যাবে।\n"
        f"৪. কোনো প্রকার ফেক রেফার বা অটো-ক্লিকার বট ব্যবহার করলে একাউন্ট ব্যান হবে।\n"
        f"৫. যেকোনো সমস্যায় অ্যাডমিনের সাথে যোগাযোগ করুন: @{config.ADMIN_USERNAME}\n"
    )
    await message.answer(help_text, parse_mode="Markdown")


# ==========================================
# 🛠️ অ্যাডমিন প্যানেল কমান্ডস
# ==========================================
@dp.message(Command("admin"))
async def admin_dashboard(message: types.Message):
    if message.from_user.id != config.ADMIN_ID:
        return

    stats = await db.get_system_stats()
    admin_text = (
        f"👑 **দেশি কাজ অ্যাডমিন প্যানেল**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👥 মোট ইউজার: {to_bangla_digits(stats['total_users'])} জন\n"
        f"🎯 মোট কাজ সম্পন্ন: {to_bangla_digits(stats['total_tasks'])} টি\n"
        f"⏳ অপেক্ষারত উইথড্র: {to_bangla_digits(stats['pending_withdrawals'])} টি\n"
        f"💵 মোট পেমেন্ট সম্পন্ন: ৳{to_bangla_digits(stats['total_paid'])} \n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📌 **কমান্ড তালিকা:**\n"
        f"• `/pending` - পেন্ডিং পেমেন্ট দেখুন\n"
        f"• `/approve <id> <trx_id>` - পেমেন্ট অনুমোদন করুন\n"
        f"• `/reject <id>` - পেমেন্ট বাতিল ও রিফান্ড করুন\n"
        f"• `/broadcast` - সকল ইউজারকে নোটিশ পাঠান"
    )
    await message.answer(admin_text, parse_mode="Markdown")


@dp.message(Command("broadcast"))
async def admin_broadcast_prompt(message: types.Message, state: FSMContext):
    if message.from_user.id != config.ADMIN_ID:
        return
    await message.answer("📢 যে নোটিশটি সকল ইউজারকে পাঠাতে চান তা লিখে পাঠান:")
    await state.set_state(BroadcastState.entering_message)


@dp.message(BroadcastState.entering_message)
async def admin_broadcast_send(message: types.Message, state: FSMContext):
    if message.from_user.id != config.ADMIN_ID:
        return
    notice_text = message.text
    user_ids = await db.get_all_user_ids()
    sent_count = 0

    await message.answer(f"⏳ মোট {len(user_ids)} জন ইউজারের কাছে পাঠানো হচ্ছে...")
    for uid in user_ids:
        try:
            await bot.send_message(uid, f"📢 **অফিসিয়াল নোটিশ:**\n\n{notice_text}", parse_mode="Markdown")
            sent_count += 1
            await asyncio.sleep(0.05)  # Telegram flood limit এড়াতে
        except Exception:
            continue

    await state.clear()
    await message.answer(f"✅ ব্রডকাস্ট সম্পন্ন! মোট {sent_count} জনের কাছে সফলভাবে পৌঁছেছে।")


# মেইন এন্ট্রি পয়েন্ট
async def main():
    logger.info("Initializing Database...")
    await db.init_db()
    logger.info("Bot is starting polling...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
