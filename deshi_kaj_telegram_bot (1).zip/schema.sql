-- দেশি কাজ টেলিগ্রাম বট ডাটাবেস স্কিমা

-- ১. ইউজার টেবিল
CREATE TABLE IF NOT EXISTS users (
    user_id BIGINT PRIMARY KEY,
    first_name VARCHAR(255),
    username VARCHAR(255),
    balance NUMERIC(10, 2) DEFAULT 0.00,
    total_tasks INT DEFAULT 0,
    last_task_time BIGINT DEFAULT 0,
    referred_by BIGINT,
    total_refers INT DEFAULT 0,
    referral_earnings NUMERIC(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ২. উইথড্রাল টেবিল
CREATE TABLE IF NOT EXISTS withdrawals (
    id SERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    method VARCHAR(50) NOT NULL,
    account_number VARCHAR(30) NOT NULL,
    amount NUMERIC(10, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    trx_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ৩. বিজ্ঞাপন ও সিস্টেম সেটিংস টেবিল
CREATE TABLE IF NOT EXISTS settings (
    key VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL
);

-- প্রাথমিক ডিফল্ট সেটিংস ইনসার্ট
INSERT OR IGNORE INTO settings (key, value) VALUES 
('reward_amount', '2.50'),
('cooldown_seconds', '300'),
('referral_bonus', '5.00'),
('min_withdrawal', '50.00');
